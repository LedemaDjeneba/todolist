import * as Signup from "./signup_form.js"

const signUpRoot= document.querySelector(".signup_form")

const signup=Signup.init(signUpRoot)