import * as Login from "./login_form.js"

const loginRoot= document.querySelector(".login_form")

const login=Login.init(loginRoot)